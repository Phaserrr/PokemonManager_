package de.uhd.ifi.pokemonmanager.ui.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

import de.uhd.ifi.pokemonmanager.R;
import de.uhd.ifi.pokemonmanager.data.Pokemon;
import de.uhd.ifi.pokemonmanager.data.Swap;

/**
 * Enables to show a list of {@link Swap}s in the UI in a so called {@link
 * androidx.recyclerview.widget.RecyclerView}.
 */
public class SwapAdapter extends RecyclerView.Adapter<SwapHolder> {
    private LayoutInflater inflater;
    private List<Swap> swaps;
    private Pokemon pokemon;

    public SwapAdapter(final Context context, final List<Swap> swaps, final Pokemon pokemon) {
        this.inflater = LayoutInflater.from(context);
        this.swaps = swaps;
        this.pokemon = pokemon;
    }

    @NonNull
    @Override
    public SwapHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new SwapHolder(inflater.inflate(R.layout.listitem_competition, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull SwapHolder holder, int position) {
        holder.setSwap(swaps.get(position), pokemon);
    }

    @Override
    public int getItemCount() {
        return swaps.size();
    }
}

/**
 * Responsible to show a single {@link Swap} in the UI.
 */
class SwapHolder extends RecyclerView.ViewHolder {

    private final TextView swapDateText;
    private final TextView swapOpponent;
    private final TextView swapResult;
    private SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy", Locale.GERMANY);

    SwapHolder(@NonNull View itemView) {
        super(itemView);
        swapDateText = itemView.findViewById(R.id.swapDateText);
        swapOpponent = itemView.findViewById(R.id.swapOpponent);
        swapResult = itemView.findViewById(R.id.swapResult);

        itemView.setTag(this);
    }

    void setSwap(Swap swap, Pokemon pokemon) {
        this.swapDateText.setText(formatter.format(swap.getDate()));
        if (swap.getSourcePokemon().equals(pokemon)) {
            this.swapOpponent.setText(swap.getTargetPokemon().getName());
        } else {
            this.swapOpponent.setText(swap.getSourcePokemon().getName());
        }
        if (swap.getSourcePokemon().equals(pokemon)) {
            this.swapResult.setText(R.string.competition_won);
        } else if (swap.getTargetPokemon().equals(pokemon)){
            this.swapResult.setText(R.string.competition_lost);
        } else {
            this.swapResult.setText(R.string.competition_draw);
        }
    }
}