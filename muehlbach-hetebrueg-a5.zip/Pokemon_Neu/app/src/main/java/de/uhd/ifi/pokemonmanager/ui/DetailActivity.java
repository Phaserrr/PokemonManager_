package de.uhd.ifi.pokemonmanager.ui;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.textfield.TextInputEditText;

import java.util.List;

import de.uhd.ifi.pokemonmanager.R;
import de.uhd.ifi.pokemonmanager.data.Competition;
import de.uhd.ifi.pokemonmanager.data.Pokemon;
import de.uhd.ifi.pokemonmanager.data.Swap;
import de.uhd.ifi.pokemonmanager.storage.SerialStorage;
import de.uhd.ifi.pokemonmanager.ui.adapter.CompetitionAdapter;
import de.uhd.ifi.pokemonmanager.ui.adapter.SwapAdapter;
import de.uhd.ifi.pokemonmanager.ui.util.RecyclerViewUtil;

public class DetailActivity extends AppCompatActivity {

    private Pokemon pokemon;
    //TODO: declare views here
    private TextInputEditText nameText;
    private TextInputEditText typeText;
    private TextInputEditText trainerText;
    private TextView swapAllowedText;
    private RecyclerView swapList;
    private RecyclerView competitionList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);


        bindViews();
        getPokemonFromIntent();
        setupSwapList();
        setupCompetitionList();
        initPokemonDetailView();
    }

    private void bindViews() {
        //TODO: bind views (findViewById)
        // Bind views using findViewById
        nameText = findViewById(R.id.nameText);
        typeText = findViewById(R.id.type);
        trainerText = findViewById(R.id.trainer);
        swapAllowedText = findViewById(R.id.swapAllowed);
        swapList = findViewById(R.id.swapList);
        competitionList = findViewById(R.id.competitionList);
    }

    private void getPokemonFromIntent() {
        //TODO
        // Get the Pokemon from the Intent
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra(MainActivity.DETAIL_POKEMON)) {
            pokemon = SerialStorage.getInstance().getPokemonById(intent.getIntExtra(MainActivity.DETAIL_POKEMON, 0));
        }
    }

    private void setupSwapList() {
        //TODO:
        // Hint: MainActivity.setupList
        // Setup RecyclerView for swaps
        List<Swap> swaps = pokemon.getSwaps();
        RecyclerView.LayoutManager manager = RecyclerViewUtil.createLayoutManager(this);
        swapList.setLayoutManager(manager);
        swapList.setAdapter(new SwapAdapter(this, swaps, pokemon)); // Assuming a SwapAdapter is available
    }

    private void setupCompetitionList() {
        //TODO
        // Setup RecyclerView for competitions
        List<Competition> competitions = pokemon.getCompetitions();
        RecyclerView.LayoutManager manager = RecyclerViewUtil.createLayoutManager(this);
        competitionList.setLayoutManager(manager);
        competitionList.setAdapter(new CompetitionAdapter(this, competitions, pokemon)); // Assuming a CompetitionAdapter is available

    }

    private void initPokemonDetailView() {
        //TODO
        // Initialize the views with Pokemon details
        if (pokemon != null) {
            nameText.setText(pokemon.getName());
            typeText.setText(pokemon.getType().toString());
            trainerText.setText(pokemon.getTrainer() != null ? pokemon.getTrainer().toString() : "No Trainer");
            swapAllowedText.setText(pokemon.isSwapAllowed() ? "Yes" : "No");
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.detail_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        boolean result = true;
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                break;
            default:
                result = super.onOptionsItemSelected(item);
        }

        return result;
    }

}
