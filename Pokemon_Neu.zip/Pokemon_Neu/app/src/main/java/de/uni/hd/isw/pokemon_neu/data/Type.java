package de.uni.hd.isw.pokemon_neu.data;

public enum Type {
    FIRE,
    WATER,
    POISON
}
