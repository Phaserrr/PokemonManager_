package de.uni.hd.isw.pokemon_neu.data;

import java.util.ArrayList;
import java.util.List;

public class Pokemon {
    // Pokemon Attribut Name
    private String name;
    // Pokemon Attribut Type
    private Type type;

    // Blatt 2
    private Trainer trainer;
    private List<Swap> swaps = new ArrayList<>();
    private boolean isSwapAllowed = true;


    // Zukünftiges Attribut eines Pokemons
    private int number;
    // statische Zählvariable, deren Wert bei Objekterzeugung inkrementiert wird und in number (Attribut) gespeichert wird
    private static int nextNumber = 1;

    // Competition
    private double combatScore = Math.random();
    private List<Competition> competitions = new ArrayList<>();

    // constructor
    public Pokemon( String pokeName, Type pokeType) {
        type = pokeType;
        name = pokeName;
        // Inkrementiere bei jedem Objekt um 1 damit Pokemon IDs eindeutig sind
        this.number = nextNumber;
        nextNumber++;// Teile dem Objekt bei Instanzierung diese ID zu
    }

    // generiert per android studio
    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }
    /*
     * Erklärung this:
     * Referenz für aktuelles Objekt in der methode setName.
     * Damit wird sichergestellt, dass tatsächlich name vom Objekt in setName verwendet wird
     * Etwaige Verwechslungen zwischen name als Klassenattribut und name als möglicher Parameter werden beseitigt.
     * Könnte mit this auch die dopplung von pokeName und name eliminieren in dem ich this.name = name; verwende
     */

    // generiert per android studio
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNumber() { // ohne setter da nummer nicht manuell gesetzt bei objekt instanzierung
        return number;
    }

    public Trainer getTrainer() {
        return trainer;
    }

    public void setTrainer(Trainer trainer) {
        this.trainer = trainer;
    }

    public void addSwap(Swap swap) {
        swaps.add(swap);
    }

    public boolean isSwappable() {
        return isSwapAllowed;
    }


    public double getCombatScore() {
        return combatScore;
    }

    public void addCompetition(Competition c) {
        competitions.add(c);
    }

    public List<Swap> getSwaps() {
        return swaps;
    }

    public List<Competition> getCompetitions() {
        return competitions;
    }

    public String toString(){
        return "Pokemon{Name = ' " + name + " ', Type = " + type + " ', ID = " + number + ";\n" + "Swaps: " + swaps.toString() + ", Competition: " + competitions.toString() +  '}';
    }

}