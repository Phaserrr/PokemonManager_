package de.uni.hd.isw.pokemon_neu.data;

public class Terminal {
    public void linkPokemonToTrainer(Pokemon p, Trainer t) {
        t.addPokemon(p);
    }

    public void listPokemonsForTrainer(Trainer t) {
        t.displayPokemons();
    }

    public void listPokemonsByType(Trainer t, Type type) {
        for (Pokemon p: t.getPokemons()) {
            if (p.getType() == type) {
                System.out.println(p.toString());
            }
        }
    }

    public void displayIthPokemon(Trainer t, int i) {
        if (i<t.getPokemons().size()) {
            System.out.println(t.getPokemons().get(i).toString());
        } else {
            System.out.println("NULL");
        }
    }
}

