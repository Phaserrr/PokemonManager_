package de.uni.hd.isw.pokemon_neu.data;

import java.util.ArrayList;
import java.util.List;

public class Trainer {

    private String firstName;
    private String lastName;
    private ArrayList<Pokemon> pokemons = new ArrayList<>();

    // auch kopiert und modifiziert von Pokemon.java
    public Trainer(String firstName, String lastName){
        this.firstName = firstName;
        this.lastName = lastName;

    }
    // Getter und Setter wurden generiert über Androdstudio
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void addPokemon(Pokemon p) {
        if (p.getTrainer() == null) {
            this.pokemons.add(p);
            p.setTrainer(this);
        } else {
            if (p.getTrainer() == this) {
                System.out.println(p.toString()+" already belongs to this Trainer");
                return;
            }
            System.out.println(p.toString()+" already belongs to another Trainer");
        }
    }

    public void removePokemon(Pokemon p) {
        pokemons.remove(p);
        p.setTrainer(null);
    }

    public void setPokemons(List<Pokemon> pokemons) {
        for (Pokemon p: pokemons) {
            addPokemon(p);
        }
    }

    public List<Pokemon> getPokemons() {
        return pokemons;
    }

    public void displayPokemons() {
        for (Pokemon p: pokemons) {
            System.out.println(p.toString());
        }
    }

    // Kopiert und modifiziert von Pokemon.java
    public String toString(){
        return firstName + ' ' + lastName;
    }
}
