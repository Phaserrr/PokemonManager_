package de.uni.hd.isw.pokemon_neu.ui.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import androidx.recyclerview.widget.RecyclerView.Adapter;

import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;

import de.uni.hd.isw.pokemon_neu.R;
import de.uni.hd.isw.pokemon_neu.data.Pokemon;

public class PokemonAdapter extends Adapter<PokemonHolder> {

    private LayoutInflater inflater;
    private List<Pokemon> pokemonList;
    private Consumer<Pokemon> onItemClick;

    public PokemonAdapter(Context context, List<Pokemon> pokemonList) {
        this.inflater = LayoutInflater.from(context);
        this.pokemonList = pokemonList;
    }

    public void setOnItemClick( Consumer<Pokemon> onItemClick) {
        this.onItemClick = onItemClick;
    }

    @NonNull
    @Override
    public PokemonHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = inflater.inflate(R.layout.listitem_string, parent, false);
        itemView.setOnClickListener(this::onItemClick);
        return new PokemonHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull PokemonHolder holder, int position) {
        holder.setPokemon(pokemonList.get(position));
    }

    private void onItemClick(View view) {
        ViewHolder holder = (ViewHolder) view.getTag();
        int pos = holder.getBindingAdapterPosition();
        Pokemon elem = pokemonList.get(pos);
        if(onItemClick != null) {
            onItemClick.accept(elem);
        }
    }

    @Override
    public int getItemCount() {
        return pokemonList.size();
    }
}

class PokemonHolder extends ViewHolder {

    private TextView pokemonName;
    private TextView pokemonType;
    private TextView pokemonId;
    private TextView trainerText;
    private TextView pokemonSwaps;
    private TextView pokemonCompetitions;

    PokemonHolder(View itemView) {
        super(itemView);
        pokemonName = itemView.findViewById(R.id.pokemonName);
        pokemonType = itemView.findViewById(R.id.pokemonType);
        pokemonId = itemView.findViewById(R.id.pokemonId);
        trainerText = itemView.findViewById(R.id.trainerText);
        pokemonSwaps = itemView.findViewById(R.id.pokemonSwaps);
        pokemonCompetitions = itemView.findViewById(R.id.pokemonCompetitions);
        itemView.setTag(this);
    }

    void setPokemon(Pokemon pokemon) {
        this.pokemonName.setText(pokemon.getName());
        this.pokemonType.setText(pokemon.getType().toString());
        this.pokemonId.setText(String.format(Locale.getDefault(),"# %d", pokemon.getNumber()));
        this.trainerText.setText(pokemon.getTrainer().toString());
        this.pokemonSwaps.setText(String.format(Locale.getDefault(),"Swaps: %d", pokemon.getSwaps().size()));
        this.pokemonCompetitions.setText(String.format(Locale.getDefault(),"Competitions: %d", pokemon.getCompetitions().size()));
    }
}

