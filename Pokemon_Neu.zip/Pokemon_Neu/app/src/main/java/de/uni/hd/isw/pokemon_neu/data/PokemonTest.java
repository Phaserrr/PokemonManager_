package de.uni.hd.isw.pokemon_neu.data;

public class PokemonTest {
    public static void main(String[] args){
        Pokemon P1 = new Pokemon("Charmander", Type.FIRE); // Erzeuge drei Pokemon unterschiedlichen Typs
        Pokemon P2 = new Pokemon("Squirtle", Type.WATER);
        Pokemon P3 = new Pokemon("Bisasam", Type.POISON);

        // Lasse alle Namen ausgeben
        System.out.println("Welche Pokemon wurden initialisiert?");
        System.out.println(P1.getName());
        System.out.println(P2.getName());
        System.out.println(P3.getName());

        // Lasse alle Typen ausgeben!
        System.out.println("Gebe alle Typen der Pokemon aus");
        System.out.println("Typ von " + P1.getName() + ": " + P1.getType());
        System.out.println("Typ von " + P2.getName() + ": " + P2.getType());
        System.out.println("Typ von " + P3.getName() + ": " + P3.getType());

        // Lasse alle IDs ausgeben
        System.out.println("Gebe alle IDs der Pokemon aus:");
        System.out.println(P1.getName() + ": " + P1.getNumber());
        System.out.println(P2.getName() + ": " + P2.getNumber());
        System.out.println(P3.getName() + ": " + P3.getNumber());

        // Überprüfe ob bei allen Pokemon die Typen zu Namen und Nummern passen
        System.out.println("Rufe alle Attribute aller Pokemon ab, die instanziert wurden:");
        System.out.println("Pokemon: " + P1.getName() + ", Typ: " + P1.getType() + ", ID: " + P1.getNumber());
        System.out.println("Pokemon: " + P2.getName() + ", Typ: " + P2.getType() + ", ID: " + P2.getNumber());
        System.out.println("Pokemon: " + P3.getName() + ", Typ: " + P3.getType() + ", ID: " + P3.getNumber());

        // Ändere Attribute der Pokemon an einem Beispiel:
        System.out.println("Charmander wird aus irgendeinem Grund auf einmal ein Wasserpokemon");
        P1.setType(Type.WATER);
        System.out.println("Pokemon: " + P1.getName() + ", Typ: " + P1.getType() + ", ID: " + P1.getNumber());

        // Teste noch übrig bleibende Operation setName
        System.out.println("Squirtle entscheidet sich seinen Namen zu aendern weil es Pikachu-Fanboy ist");
        P2.setName("Pikachu-Lover");
        System.out.println("Pokemon: " + P2.getName() + ", Typ: " + P2.getType() + ", ID: " + P2.getNumber());

        // setNumber existiert nicht

        // sonst kann man nur noch toString testen
        System.out.println("Benutze eine coole Java Funktion toString um alle Attribute von Bisasam ausgeben zu lassen: ");
        System.out.println(P3.toString());

        // So wurden alle Operationen getestet: setName, getName, setType, getType, getNumber und toString()



        // a2.1.3.

        /*
         * Zu testende Operationen
         *
         *
         * Getter und Setter für firstName, lastName, und pokemons
         * ToString
         * AddPokemon
         * Display Pokemons
         * linkPokemonToTrainer
         * listPokemonsByType
         * listPokemonsForTrainer
         * displayIthPokemon
         *
         * */

        Trainer Sabrina = new Trainer("Sabrina", "Ravenclaw");
        Trainer Rocko = new Trainer("Rocko", "Balboa");
        Trainer Norbert = new Trainer("Norbert", "Siegfried");

        System.out.println("Welche Trainer gibt es?");
        System.out.println(Sabrina.getFirstName() + " " + Sabrina.getLastName());
        System.out.println(Rocko.getFirstName() + " " + Rocko.getLastName());
        System.out.println(Norbert.getFirstName() + " " + Norbert.getLastName());

        System.out.println("Norbert ändert seinen Namen zu Nora");
        Norbert.setFirstName("Nora");
        System.out.println(Norbert.getFirstName());

        System.out.println("Nora heiratet und ändert ihren Nachnamen");
        Norbert.setLastName("Sieglinde");
        System.out.println(Norbert.getLastName());

        System.out.println("Charmander und Pikachu-Lover werden von Sabrina gefangen");
        Sabrina.addPokemon(P1);
        Sabrina.addPokemon(P2);
        System.out.println("Welche Pokemons besitzt Sabrina?");
        System.out.println(Sabrina.getPokemons());

        System.out.println("Rocko fängt Bisasam");
        Rocko.addPokemon(P3);
        System.out.println("Welche Pokemons besitzt Rocko?");
        System.out.println(Rocko.getPokemons());

        // Testen der Swap-Klasse
        System.out.println("Die Trainer von Bisasam und Charmander werden getauscht");
        Swap s1 = new Swap(P1,P3);
        s1.execute();
        System.out.println("Welche Pokemons besitzt Sabrina jetzt?");
        System.out.println(Sabrina.getPokemons());
        System.out.println("Welche Pokemons besitzt Rocko?");
        System.out.println(Rocko.getPokemons());
        System.out.println(s1.toString());

        System.out.println("Was passiert, wenn man die Trainer von Sabrinas Pokemons tauschen möchte?");
        Swap s2 = new Swap(P2,P3);
        s2.execute();

        Pokemon P4 = new Pokemon("Glumanda", Type.FIRE);
        System.out.println("Was passiert, wenn man ein herrenloses Pokemon wechseln möchte?");
        Swap s3 = new Swap(P2,P4);
        s3.execute();


        // Testen der Competition-Klasse
        Pokemon P5 = new Pokemon("Glutexo", Type.FIRE);
        Pokemon P6 = new Pokemon("Rettan", Type.POISON);
        Pokemon P7 = new Pokemon("Enton", Type.WATER);
        Pokemon P8 = new Pokemon("Fukano", Type.FIRE);

        Sabrina.addPokemon(P5);
        Sabrina.addPokemon(P6);
        Rocko.addPokemon(P7);
        Norbert.addPokemon(P8);

        Competition C1 = new Competition(P5, P6);
        C1.execute();

        Competition C2 = new Competition(P5, P7);
        C2.execute();

        Competition C3 = new Competition(P6, P8);
        C3.execute();

        Competition C4 = new Competition(P7, P8);
        C4.execute();

    }
}
