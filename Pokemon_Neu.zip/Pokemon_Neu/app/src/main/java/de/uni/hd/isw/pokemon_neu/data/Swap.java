package de.uni.hd.isw.pokemon_neu.data;

import java.util.Date;

public class Swap {

    private Pokemon p1;
    private Trainer t1;
    private Pokemon p2;
    private Trainer t2;

    protected Date date;
    protected String id;
    protected static int nextID = 0;

    private boolean isSwapAllowed() {

        if (this.p1.getTrainer() == null || this.p2.getTrainer() == null) {
            System.out.println("At least one of the Pokemons does not have a trainer");
            return false;
        }
        if (this.p1.getTrainer() == this.p2.getTrainer()) {
            System.out.println("Pokemon " + this.p1.getName() + " kann nicht mit " + this.p2.getName() +
                    " getauscht werden, da beide den/die TrainerIn " +
                    this.p1.getTrainer().getFirstName() + " " + this.p1.getTrainer().getLastName() + " haben.");
            return false;
        }
        if (!p1.isSwappable() || !p2.isSwappable()) {
            if (p1.isSwappable() && p2.isSwappable()) {
                System.out.println("Pokemon " + p1.getName() + " und " + p2.getName() + " sind nicht zum Tauschen freigegeben");
            }
            else if (!p1.isSwappable()) {
                System.out.println("Pokemon " + p1.getName() + " ist nicht zum Tauschen freigegeben");
            }
            else if (!p2.isSwappable()) {
                System.out.println("Pokemon " + p2.getName() + " ist nicht zum Tauschen freigegeben");
            }
            return false;
        }

        // else
        return true;
    }

    public String toString() {
        return "Swap{" + p1.toString() + ": " + t2.toString() + "; " + p2.toString() + ": " + t1.toString() + "; " + date.toString() + "; ID: " + id + "}";
    }

    public static void increaseNextID() {
        nextID++;
    }

    public void execute() {

        if (!this.isSwapAllowed()) {
            return;
        }

        t1.removePokemon(p1);
        t2.removePokemon(p2);
        t1.addPokemon(p2);
        t2.addPokemon(p1);
        date = new Date();

        id = String.valueOf(nextID);
        increaseNextID();

        p1.addSwap(this);
        p2.addSwap(this);
    }



    public Pokemon getP1() {
        return p1;
    }

    public Trainer getT1() {
        return t1;
    }

    public Pokemon getP2() {
        return p2;
    }

    public Trainer getT2() {
        return t2;
    }

    public Date getDate() {
        return date;
    }

    public String getId() {
        return id;
    }

    public Swap(Pokemon p1, Pokemon p2) {
        this.p1 = p1;
        this.p2 = p2;
        this.t1 = p1.getTrainer();
        this.t2 = p2.getTrainer();
    }
}
