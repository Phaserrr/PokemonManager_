package de.uni.hd.isw.pokemon_neu.data;

import java.util.Date;

public class Competition extends Swap {

    private boolean isDraw;
    private Pokemon winningPokemon;
    private Pokemon losingPokemon;

    public Competition(Pokemon p1, Pokemon p2) {
        super(p1,p2);
    }

    private void getWinner(Pokemon advantagedPokemon, Pokemon disadvantagedPokemon, boolean advantageIsEnabled) {
        if (advantageIsEnabled) {
            if (advantagedPokemon.getCombatScore() * 2 > disadvantagedPokemon.getCombatScore()) {
                winningPokemon = advantagedPokemon;
                losingPokemon = disadvantagedPokemon;
                isDraw = false;
            } else if (advantagedPokemon.getCombatScore() * 2 < disadvantagedPokemon.getCombatScore()) {
                winningPokemon = disadvantagedPokemon;
                losingPokemon = advantagedPokemon;
                isDraw = false;
            } else {
                isDraw = true;
            }
        }
        else {
            if (advantagedPokemon.getCombatScore() > disadvantagedPokemon.getCombatScore()) {
                winningPokemon = advantagedPokemon;
                losingPokemon = disadvantagedPokemon;
                isDraw = false;
            } else if (advantagedPokemon.getCombatScore() < disadvantagedPokemon.getCombatScore()) {
                winningPokemon = disadvantagedPokemon;
                losingPokemon = advantagedPokemon;
                isDraw = false;
            } else {
                isDraw = true;
            }
        }
    }

    @Override
    public String toString() {
        if (!isDraw) {
            return "Competition{" + winningPokemon.getName() + " with Combat-Score: " + winningPokemon.getCombatScore() + " won against "
                    + losingPokemon.getName() + " with Combat-Score: " + losingPokemon.getCombatScore() + "; " + super.getDate().toString() + "; ID: " + super.getId() + "}";
        }
        return "Competition{" + winningPokemon.getName() + " draws with " + losingPokemon.getName() + "; " + super.getDate().toString() + "; ID: " + super.getId() + "}";
    }

    @Override
    public void execute() {
        if (super.getT1()==super.getT2()) {
            System.out.println("competition not allowed for same trainers");
            return;
        }

        if (super.getP1().getType() == Type.FIRE) {
            if (super.getP2().getType() == Type.POISON) {
                getWinner(super.getP1(), super.getP2(),true);
            }
            else {
                getWinner(super.getP2(), super.getP1(), super.getP2().getType() == Type.WATER);
            }
        }

        if (super.getP1().getType() == Type.WATER) {
           if (super.getP2().getType() == Type.FIRE) {
               getWinner(super.getP1(), super.getP2(),true);
           }
           else {
               getWinner(super.getP2(), super.getP1(), super.getP2().getType() == Type.POISON);
           }
        }

        if (super.getP1().getType() == Type.POISON) {
            if (super.getP2().getType() == Type.WATER) {
                getWinner(super.getP1(), super.getP2(),true);
            }
            else {
                getWinner(super.getP2(), super.getP1(), super.getP2().getType() == Type.FIRE);
            }
        }

        super.getP1().addCompetition(this);
        super.getP2().addCompetition(this);

        if (!isDraw) {
            losingPokemon.getTrainer().removePokemon(losingPokemon);
            winningPokemon.getTrainer().addPokemon(losingPokemon);
        }

        date = new Date();

        id = String.valueOf(nextID);
        increaseNextID();

        System.out.println(toString());
    }
}
