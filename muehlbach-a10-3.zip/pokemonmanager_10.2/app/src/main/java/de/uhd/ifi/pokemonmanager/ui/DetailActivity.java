package de.uhd.ifi.pokemonmanager.ui;

import static de.uhd.ifi.pokemonmanager.ui.MainActivity.DETAIL_POKEMON;
import static de.uhd.ifi.pokemonmanager.ui.util.RecyclerViewUtil.createLayoutManager;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;

import java.util.Arrays;
import java.util.List;

import de.uhd.ifi.pokemonmanager.R;
import de.uhd.ifi.pokemonmanager.data.Competition;
import de.uhd.ifi.pokemonmanager.data.Pokemon;
import de.uhd.ifi.pokemonmanager.data.Swap;
import de.uhd.ifi.pokemonmanager.data.Trainer;
import de.uhd.ifi.pokemonmanager.data.Type;
import de.uhd.ifi.pokemonmanager.storage.SerialStorage;
import de.uhd.ifi.pokemonmanager.ui.adapter.CompetitionAdapter;
import de.uhd.ifi.pokemonmanager.ui.adapter.SwapAdapter;

public class DetailActivity extends AppCompatActivity {

    // Views
    private EditText nameEditText;
    private MaterialAutoCompleteTextView typeSpinner;
    private TextView trainer;
    private Button addTrainerButton;
    private Switch swapAllowedSwitch;
    private RecyclerView swapList;
    private RecyclerView competitionList;
    private Pokemon pokemon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        bindViews();
        getPokemonFromIntent();
        initPokemonDetailView();
        setupSwapList();
        setupCompetitionList();
        beginListening();
    }

    private void bindViews() {
        nameEditText = findViewById(R.id.nameEditText);
        typeSpinner = findViewById(R.id.typeSpinner);
        typeSpinner.setSimpleItems(Arrays.stream(Type.values()).map(Enum::toString).toArray(String[]::new));
        trainer = findViewById(R.id.trainer);
        swapAllowedSwitch = findViewById(R.id.swapAllowedSwitch);
        addTrainerButton = findViewById(R.id.addTrainerButton);
        swapList = findViewById(R.id.swapList);
        competitionList = findViewById(R.id.competitionList);
    }

    private void getPokemonFromIntent() {
        Intent intent = getIntent();
        Parcelable parcelable = intent.getParcelableExtra(DETAIL_POKEMON);
        pokemon = SerialStorage.getInstance().getPokemonById(((Pokemon) parcelable).getId());
    }

    private void setupSwapList() {
        List<Swap> swapsOfPokemon = pokemon.getSwaps();
        SwapAdapter swapAdapter = new SwapAdapter(this, swapsOfPokemon, pokemon);
        RecyclerView.LayoutManager manager = createLayoutManager(this);

        swapList.setLayoutManager(manager);
        swapList.setAdapter(swapAdapter);
    }

    private void setupCompetitionList() {
        List<Competition> competitionsOfPokemon = pokemon.getCompetitions();
        CompetitionAdapter competitionAdapter = new CompetitionAdapter(this, competitionsOfPokemon, pokemon);
        RecyclerView.LayoutManager manager = createLayoutManager(this);

        competitionList.setLayoutManager(manager);
        competitionList.setAdapter(competitionAdapter);
    }

    private void initPokemonDetailView() {
        nameEditText.setText(pokemon.getName());
        typeSpinner.setText(pokemon.getType().toString(), false);
        trainer.setText(pokemon.getTrainer().toString());
        swapAllowedSwitch.setChecked(pokemon.isSwapAllowed());
    }

    private void beginListening() {
        addTrainerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                View layout = getLayoutInflater().inflate(R.layout.dialog_input_names, null);

                new MaterialAlertDialogBuilder(view.getContext())
                        .setTitle(R.string.dialog_title_add_trainer)
                        .setView(layout)
                        .setPositiveButton(R.string.dialog_create, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int id) {
                                EditText inputFirstName = layout.findViewById(R.id.input_first_name);
                                EditText inputLastName = layout.findViewById(R.id.input_last_name);
                                String firstName = inputFirstName.getText().toString();
                                String lastName = inputLastName.getText().toString();
                                if (!firstName.isEmpty() && !lastName.isEmpty()) {
                                    Trainer trainer = new Trainer(firstName, lastName);
                                    SerialStorage.getInstance().save(trainer);
                                    dialog.dismiss();
                                } else {
                                    Toast.makeText(view.getContext(), R.string.warning_non_empty_name, Toast.LENGTH_LONG).show();
                                }
                            }
                        })
                        .setNegativeButton(R.string.delete_cancel, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.dismiss();
                            }
                        }).show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.detail_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        boolean result = true;
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                break;
            default:
                result = super.onOptionsItemSelected(item);
        }

        return result;
    }

    private void savePokemonDetails() {
        pokemon.setName(nameEditText.getText().toString());
        pokemon.setType(Type.valueOf(typeSpinner.getText().toString()));
        pokemon.setSwapAllowed(swapAllowedSwitch.isChecked());
        SerialStorage.getInstance().save(pokemon);
        Toast.makeText(this, "Pokemon details saved", Toast.LENGTH_SHORT).show();
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        new MaterialAlertDialogBuilder(this)
                .setMessage(R.string.save_detail_message)
                .setTitle(R.string.save_detail_title)
                .setPositiveButton(R.string.save_detail_positive, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        savePokemonDetails();
                        DetailActivity.super.onBackPressed();
                    }
                })
                .setNegativeButton(R.string.delete_cancel, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.dismiss();
                    }
                })
                .create()
                .show();
    }
}

/*
Testfälle:

Edit Pokemon:
Testen, ob der Name des Pokémon bearbeitet und korrekt angezeigt wird.
Testen, ob der Typ des Pokémon bearbeitet und korrekt angezeigt wird.
Testen, ob isSwapAllowed bearbeitet und korrekt angezeigt wird.
Testen, ob Änderungen verworfen werden, wenn der Benutzer den Dialog abbricht.

Save Pokemon:
Testen, ob die Änderungen korrekt gespeichert werden.
Testen, ob die Liste der Pokémon nach dem Speichern aktualisiert wird.
Testen, ob der Benutzer zur Listenansicht zurückkehren kann, ohne die Änderungen zu speichern

 */