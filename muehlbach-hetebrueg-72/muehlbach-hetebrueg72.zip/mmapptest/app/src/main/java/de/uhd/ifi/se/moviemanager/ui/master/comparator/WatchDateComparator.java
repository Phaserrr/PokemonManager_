package de.uhd.ifi.se.moviemanager.ui.master.comparator;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;

import de.uhd.ifi.se.moviemanager.model.Movie;


public class WatchDateComparator implements CategorizedComparator<Movie> {
    @Override
    public int compare(Movie movie1, Movie movie2) {
        if (movie1.getWatchDate() == null && movie2.getWatchDate() == null) {
            return 0;
        }
        if (movie1.getWatchDate() == null) {
            return 1;
        }
        if (movie2.getWatchDate() == null) {
            return -1;
        }
        return movie1.getWatchDate().compareTo(movie2.getWatchDate());
    }

    @Override
    public String getCategoryNameFor(Movie movie) {
        if (movie.getWatchDate() == null) {
            return "";
        }



        LocalDate watchDate = movie.getWatchDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        LocalDate today = LocalDate.now();

        long daysBetween = ChronoUnit.DAYS.between(watchDate, today);

        if (daysBetween == 0) {
            return "today";
        } else if (daysBetween == 1) {
            return "yesterday";
        } else if (daysBetween <= 7) {
            return "last week";
        } else if (daysBetween <= 30) {
            return "last month";
        } else if (daysBetween <= 365) {
            return "last year";
        } else {
            return "long time ago";
        }
    }

    @Override
    public String getSubText(Movie movie) {
        if (movie.getWatchDate() == null) {
            return "not watched";
        }
        return movie.getWatchDate().toString();
    }
}
