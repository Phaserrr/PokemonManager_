/**
 * Package containing utility classes such as
 * {@link de.uhd.ifi.se.moviemanager.util.DateUtils},
 * {@link de.uhd.ifi.se.moviemanager.util.FileUtils}, ...
 */
package de.uhd.ifi.se.moviemanager.util;