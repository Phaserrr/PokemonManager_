/**
 * This package contains the classes to create the MasterViews and related
 * functionality such as sorting and filtering.
 *
 * @see de.uhd.ifi.se.moviemanager.ui.master.DataMasterFragment
 * @see de.uhd.ifi.se.moviemanager.ui.master.comparator.CategorizedComparator
 */
package de.uhd.ifi.se.moviemanager.ui.master;