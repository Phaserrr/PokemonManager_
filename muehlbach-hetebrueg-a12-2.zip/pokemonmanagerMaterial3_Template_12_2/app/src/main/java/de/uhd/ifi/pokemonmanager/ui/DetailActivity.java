package de.uhd.ifi.pokemonmanager.ui;

import static de.uhd.ifi.pokemonmanager.ui.MainActivity.DETAIL_POKEMON;
import static de.uhd.ifi.pokemonmanager.ui.util.RecyclerViewUtil.createLayoutManager;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import de.uhd.ifi.pokemonmanager.R;
import de.uhd.ifi.pokemonmanager.data.Competition;
import de.uhd.ifi.pokemonmanager.data.Pokemon;
import de.uhd.ifi.pokemonmanager.data.Swap;
import de.uhd.ifi.pokemonmanager.data.Trainer;
import de.uhd.ifi.pokemonmanager.data.Type;
import de.uhd.ifi.pokemonmanager.storage.SerialStorage;
import de.uhd.ifi.pokemonmanager.ui.adapter.CompetitionAdapter;
import de.uhd.ifi.pokemonmanager.ui.adapter.SwapAdapter;
import de.uhd.ifi.pokemonmanager.ui.adapter.TrainerAdapter;

public class DetailActivity extends AppCompatActivity {

    private static final SerialStorage STORAGE = SerialStorage.getInstance();
    private EditText name;
    private MaterialAutoCompleteTextView typeSpinner;
    private MaterialAutoCompleteTextView trainer;
    private TrainerAdapter trainerAdapter;
    private Button addTrainerButton;
    private Button swapButton;
    private Switch swapAllowed;
    private RecyclerView swapList;
    private RecyclerView competitionList;
    private Pokemon pokemon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        bindViews();
        getPokemonFromIntent();
        setupSwapList();
        setupCompetitionList();
        initPokemonDetailView();
        beginListening();
    }

    private void populateTrainers(){
        trainerAdapter = new TrainerAdapter(this, new ArrayList<>(STORAGE.getAllTrainers()));
        trainer.setAdapter(
                trainerAdapter
        );
        trainer.setText(pokemon.getTrainer().toString(), false);
    }

    private void bindViews() {
        name = findViewById(R.id.name);
        typeSpinner = findViewById(R.id.typeSpinner);
        typeSpinner.setSimpleItems(Arrays.stream(Type.values()).map(Enum::toString).toArray(String[]::new));
        trainer = findViewById(R.id.trainer);
        swapAllowed = findViewById(R.id.swapAllowed);
        addTrainerButton = findViewById(R.id.addTrainerButton);
        swapButton = findViewById(R.id.swapButton);
        swapList = findViewById(R.id.swapList);
        competitionList = findViewById(R.id.competitionList);
    }

    private void getPokemonFromIntent() {
        Intent intent = getIntent();
        Parcelable parcelable = intent.getParcelableExtra(DETAIL_POKEMON);
        pokemon = STORAGE.getPokemonById(((Pokemon) parcelable).getId());
    }

    private void setupSwapList() {
        List<Swap> swapsOfPokemon = pokemon.getSwaps();
        SwapAdapter swapAdapter = new SwapAdapter(this, swapsOfPokemon, pokemon);
        RecyclerView.LayoutManager manager = createLayoutManager(this);

        swapList.setLayoutManager(manager);
        swapList.setAdapter(swapAdapter);
    }

    private void setupCompetitionList() {
        List<Competition> competitionsOfPokemon = pokemon.getCompetitions();
        CompetitionAdapter competitionAdapter = new CompetitionAdapter(this, competitionsOfPokemon, pokemon);
        RecyclerView.LayoutManager manager = createLayoutManager(this);

        competitionList.setLayoutManager(manager);
        competitionList.setAdapter(competitionAdapter);
    }


    private void updateSwitchText() {
        swapAllowed.setText(String.valueOf(pokemon.isSwapAllowed()));
        swapAllowed.setChecked(pokemon.isSwapAllowed());
    }


    private void initPokemonDetailView() {
        name.setText(pokemon.getName());
        typeSpinner.setText(pokemon.getType().toString(), false);
        swapButton.setEnabled(pokemon.isSwapAllowed());
        updateSwitchText();
        populateTrainers();
    }

    /**
     * Sets the event listeners on the buttons in the pokemon detail view, e.g. to create a new {@link Trainer}.
     */
    private void beginListening() {
        name.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                pokemon.setName(s.toString());
            }
        });
        typeSpinner.setOnItemClickListener((parent, view, position, id) -> pokemon.setType(Type.valueOf(typeSpinner.getText().toString())));
        trainer.setOnItemClickListener((parent, view, position, id) -> trainerAdapter.getTrainer(position).addPokemon(pokemon));
        swapAllowed.setOnCheckedChangeListener((buttonView, isChecked) -> {
            pokemon.setSwapAllowed(isChecked);
            swapButton.setEnabled(isChecked); // Enable or disable swap button
            updateSwitchText();
        });
        addTrainerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                View layout = getLayoutInflater().inflate(R.layout.dialog_input_names, null);

                new MaterialAlertDialogBuilder(view.getContext())
                        .setTitle(R.string.dialog_title_add_trainer).setView(layout).setPositiveButton(R.string.dialog_create, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int id) {
                                EditText inputFirstName = layout.findViewById(R.id.input_first_name);
                                EditText inputLastName = layout.findViewById(R.id.input_last_name);
                                String firstName = "" + inputFirstName.getText();
                                String lastName = "" + inputLastName.getText();
                                if (!firstName.isEmpty() && !lastName.isEmpty()) {
                                    Trainer trainer = new Trainer(firstName, lastName);
                                    STORAGE.save(trainer);
                                    trainer.addPokemon(pokemon);
                                    populateTrainers();
                                    dialog.dismiss();
                                } else {
                                    Toast.makeText(view.getContext(), R.string.warning_non_empty_name, Toast.LENGTH_LONG).show();
                                }
                            }
                        }).setNegativeButton(R.string.delete_cancel, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.dismiss();
                            }
                        }).show();
            }
        });
        swapButton.setOnClickListener(view -> {
            if (pokemon.isSwapAllowed()) {
                showPokemonSelectionDialog();
            } else {
                Toast.makeText(this, "Swap not allowed if not enabled for both pokemons", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showPokemonSelectionDialog() {
        List<Pokemon> availablePokemons = getAvailablePokemons();

        MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(this);
        builder.setTitle("Select a Pokemon to swap with");

        String[] pokemonNames = new String[availablePokemons.size()];
        for (int i = 0; i < availablePokemons.size(); i++) {
            pokemonNames[i] = availablePokemons.get(i).getName();
        }

        builder.setItems(pokemonNames, (dialog, which) -> {
            Pokemon p2 = availablePokemons.get(which);
            Trainer t2 = p2.getTrainer();

            if (pokemon.getTrainer().equals(t2)) {
                Toast.makeText(this, "Swap cannot be executed for same trainers", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!p2.isSwapAllowed()) {
                Toast.makeText(this, "Swap not allowed if not enabled for both pokemons", Toast.LENGTH_SHORT).show();
                return;
            }

            // Perform the swap
            performSwap(pokemon, p2);
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
        builder.show();
    }

    private List<Pokemon> getAvailablePokemons() {
        // Fetch available Pokemons
        return STORAGE.getAllPokemons().stream()
                .filter(p -> !p.equals(pokemon) && p.isSwapAllowed())
                .collect(Collectors.toList());
    }

    private void performSwap(Pokemon p1, Pokemon p2) {
        Trainer t1 = p1.getTrainer();
        Trainer t2 = p2.getTrainer();

        p1.setTrainer(t2);
        p2.setTrainer(t1);

        p1.incrementSwaps(); // Increment swaps
        p2.incrementSwaps(); // Increment swaps

        Swap swap1 = new Swap(p1, t2);
        Swap swap2 = new Swap(p2, t1);

        p1.addSwap(swap1);
        p2.addSwap(swap2);

        // Update the UI with the new details of p1
        updatePokemonDetails(p1);
    }

    private void updatePokemonDetails(Pokemon p1) {
        name.setText(p1.getName());
        typeSpinner.setText(p1.getType().toString(), false);
        trainer.setText(p1.getTrainer().toString(), false);
        updateSwitchText();
        setupSwapList();
        setupCompetitionList();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.detail_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        boolean result = true;
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                break;
            default:
                result = super.onOptionsItemSelected(item);
        }

        return result;
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        new MaterialAlertDialogBuilder(this).setMessage(R.string.save_detail_message).setTitle(R.string.save_detail_title)
                .setPositiveButton(R.string.save_detail_positive, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        STORAGE.save(pokemon);
                        STORAGE.save(pokemon.getTrainer());
                        STORAGE.saveAll(DetailActivity.this);
                        DetailActivity.super.onBackPressed();
                    }
                })
                .setNegativeButton(R.string.save_detail_negative, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        DetailActivity.super.onBackPressed();
                    }
                })
                .create().show();
    }
}