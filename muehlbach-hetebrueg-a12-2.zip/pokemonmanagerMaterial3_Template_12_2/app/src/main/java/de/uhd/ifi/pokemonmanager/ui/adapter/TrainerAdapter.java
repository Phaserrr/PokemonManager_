package de.uhd.ifi.pokemonmanager.ui.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import de.uhd.ifi.pokemonmanager.R;
import de.uhd.ifi.pokemonmanager.data.Trainer;

public class TrainerAdapter extends ArrayAdapter<Trainer> {
    private ArrayList<Trainer> trainers;

    public TrainerAdapter(Context context, ArrayList<Trainer> trainers) {
        super(context, 0, trainers);
        this.trainers = trainers;
    }

    public View getView(int position, View view, ViewGroup parent) {
        if (view == null) {
            view = LayoutInflater.from(getContext()).inflate(android.R.layout.simple_list_item_1, parent, false);
        }
        Trainer trainer = trainers.get(position);
        if (trainer != null) {
            ((TextView) view).setText(trainer.getFirstName() + " " + trainer.getLastName());
        }
        return view;
    }

    public Trainer getTrainer(int position) {
        return trainers.get(position);
    }
}
